package com.example.wallpaper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
